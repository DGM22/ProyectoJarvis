import { Injectable, Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import {
  CompareFacesCommand,
  InvalidParameterException,
  RekognitionClient,
} from '@aws-sdk/client-rekognition';

export interface FaceComparison {
  faceFound: boolean;
  similarity: number | null;
}

export interface FaceComparer {
  readonly configured: boolean;
  compare(reference: Buffer, candidate: Buffer): Promise<FaceComparison>;
}

export const FACE_COMPARER = Symbol('FACE_COMPARER');

@Injectable()
export class RekognitionFaceComparer implements FaceComparer {
  private logger = new Logger(RekognitionFaceComparer.name);
  private client: RekognitionClient | null;

  constructor(configService: ConfigService) {
    const region = configService.get<string>('aws.region');
    this.client = region ? new RekognitionClient({ region }) : null;
    if (!this.client) {
      this.logger.warn('AWS_REGION is not set: face verification is disabled');
    }
  }

  get configured() {
    return this.client !== null;
  }

  async compare(reference: Buffer, candidate: Buffer) {
    if (!this.client) {
      throw new Error('Rekognition is not configured');
    }
    try {
      const output = await this.client.send(
        new CompareFacesCommand({
          SourceImage: { Bytes: reference },
          TargetImage: { Bytes: candidate },
          SimilarityThreshold: 0,
          QualityFilter: 'AUTO',
        }),
      );
      const similarities = (output.FaceMatches ?? [])
        .map((match) => match.Similarity)
        .filter((value): value is number => typeof value === 'number');
      const unmatched = output.UnmatchedFaces?.length ?? 0;
      if (similarities.length === 0 && unmatched === 0) {
        return { faceFound: false, similarity: null };
      }
      return {
        faceFound: true,
        similarity: similarities.length > 0 ? Math.max(...similarities) : 0,
      };
    } catch (error) {
      if (error instanceof InvalidParameterException) {
        this.logger.warn(`CompareFaces without usable face: ${error.message}`);
        return { faceFound: false, similarity: null };
      }
      throw error;
    }
  }
}
