import { Logger } from '@nestjs/common';
import {
  OnGatewayConnection,
  OnGatewayDisconnect,
  WebSocketGateway,
} from '@nestjs/websockets';
import type WebSocket from 'ws';
import { CameraHubService } from './camera-hub.service';

@WebSocketGateway({ path: '/camera-view', cors: true })
export class CameraViewGateway
  implements OnGatewayConnection, OnGatewayDisconnect
{
  private logger = new Logger(CameraViewGateway.name);

  constructor(private cameraHub: CameraHubService) {}

  handleConnection(client: WebSocket) {
    this.logger.log('Camera viewer connected');
    this.cameraHub.addViewer(client);
  }

  handleDisconnect(client: WebSocket) {
    this.cameraHub.removeViewer(client);
    this.logger.log('Camera viewer disconnected');
  }
}
