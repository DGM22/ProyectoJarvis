import { Module } from '@nestjs/common';
import { CameraHubService } from './camera-hub.service';

@Module({
  providers: [CameraHubService],
  exports: [CameraHubService],
})
export class CameraHubModule {}
