#pragma once

#include <stdint.h>

bool voiceBegin();

void voiceConnect(const char *host, uint16_t port, const char *token, bool tls);

void voiceLoop();

void voiceToggleSession();

bool voiceInSession();
