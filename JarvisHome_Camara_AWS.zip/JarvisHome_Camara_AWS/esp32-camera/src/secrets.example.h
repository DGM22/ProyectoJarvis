#pragma once

#define WIFI_SSID "TuRed-2.4GHz"
#define WIFI_PASS "TuPassword"

#define JARVIS_BACKEND_HOST "jarvis.gms-app.com"
#define JARVIS_BACKEND_PORT 443
#define JARVIS_USE_TLS 1

#define JARVIS_DEVICE_TOKEN "jdv_replace_me"
