#include <Arduino.h>
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <WebSocketsClient.h>
#include <time.h>
#include "esp_camera.h"
#include "img_converters.h"
#include "robot_eyes.h"
#include "secrets.h"
#include "voice.h"

#ifndef JARVIS_VOICE_TOKEN
#define JARVIS_VOICE_TOKEN JARVIS_DEVICE_TOKEN
#endif

static constexpr int JPEG_QUALITY = 40;
static constexpr int XCLK_HZ = 20000000;

static constexpr uint32_t MIN_FRAME_GAP_MS = 80;

static constexpr uint32_t CALL_FRAME_GAP_MS = 160;

#define PWDN_GPIO_NUM -1
#define RESET_GPIO_NUM -1
#define XCLK_GPIO_NUM 15
#define SIOD_GPIO_NUM 4
#define SIOC_GPIO_NUM 5
#define Y2_GPIO_NUM 11
#define Y3_GPIO_NUM 9
#define Y4_GPIO_NUM 8
#define Y5_GPIO_NUM 10
#define Y6_GPIO_NUM 12
#define Y7_GPIO_NUM 18
#define Y8_GPIO_NUM 17
#define Y9_GPIO_NUM 16
#define VSYNC_GPIO_NUM 6
#define HREF_GPIO_NUM 7
#define PCLK_GPIO_NUM 13

#define OLED_SDA_PIN 41
#define OLED_SCL_PIN 42

#define BUTTON_PIN 14
#define LED_PIN 2

static constexpr int kReservedPins[] = {
    XCLK_GPIO_NUM, SIOD_GPIO_NUM, SIOC_GPIO_NUM, Y2_GPIO_NUM,   Y3_GPIO_NUM,
    Y4_GPIO_NUM,   Y5_GPIO_NUM,   Y6_GPIO_NUM,   Y7_GPIO_NUM,   Y8_GPIO_NUM,
    Y9_GPIO_NUM,   VSYNC_GPIO_NUM, HREF_GPIO_NUM, PCLK_GPIO_NUM, OLED_SDA_PIN,
    OLED_SCL_PIN,

    40, 39, 21, 47, 48, 1,
};

static constexpr bool isReservedPin(int pin, size_t i = 0)
{
    return i < sizeof(kReservedPins) / sizeof(kReservedPins[0]) &&
           (kReservedPins[i] == pin || isReservedPin(pin, i + 1));
}

static_assert(!isReservedPin(BUTTON_PIN), "BUTTON_PIN choca con la cámara, la OLED o el audio");
static constexpr uint32_t BUTTON_DEBOUNCE_MS = 30;
static_assert(!isReservedPin(LED_PIN), "LED_PIN choca con la cámara, la OLED o el audio");
static constexpr uint32_t LED_ON_MS = 30000;

static WebSocketsClient webSocket;
static volatile bool wsConnected = false;
static volatile bool streamEnabled = false;
static bool cameraReady = false;
static bool ntpDone = false;
static bool backendStarted = false;
static bool audioReady = false;
static bool ledOn = false;
static uint32_t ledOnSinceMs = 0;

static void turnLedOn()
{
    digitalWrite(LED_PIN, HIGH);
    ledOn = true;
    ledOnSinceMs = millis();
    Serial.println("led.on");
}

static void updateLed()
{
    if (ledOn && millis() - ledOnSinceMs >= LED_ON_MS) {
        digitalWrite(LED_PIN, LOW);
        ledOn = false;
        Serial.println("led.off");
    }
}

static void sendHello()
{
    webSocket.sendTXT(
        "{\"type\":\"hello\",\"firmwareVersion\":\"0.5.0\",\"capabilities\":[\"camera\"]}");
}

static void handleServerText(const char *json)
{
    if (strstr(json, "led.on") != nullptr) {
        turnLedOn();
        return;
    }
    if (strstr(json, "stream.on") != nullptr) {
        streamEnabled = true;
        Serial.println("stream.on");
        return;
    }
    if (strstr(json, "stream.off") != nullptr) {
        streamEnabled = false;
        Serial.println("stream.off");
        return;
    }
    if (strstr(json, "hello.ack") != nullptr) {
        Serial.println("hello.ack");
    }
}

static void onWsEvent(WStype_t type, uint8_t *payload, size_t length)
{
    switch (type) {
    case WStype_DISCONNECTED:
        wsConnected = false;
        streamEnabled = false;
        Serial.println("WS desconectado");
        break;
    case WStype_CONNECTED:
        wsConnected = true;
        Serial.printf("WS conectado a %s\n", JARVIS_BACKEND_HOST);
        sendHello();
        break;
    case WStype_TEXT: {
        char buf[256];
        const size_t n = length < sizeof(buf) - 1 ? length : sizeof(buf) - 1;
        memcpy(buf, payload, n);
        buf[n] = '\0';
        handleServerText(buf);
        break;
    }
    default:
        break;
    }
}

static void waitForNtp()
{
    configTime(0, 0, "time.google.com", "pool.ntp.org");
    Serial.print("NTP");
    for (int i = 0; i < 40; i++) {
        time_t now = time(nullptr);
        if (now > 1700000000) {
            Serial.println(" ok");
            return;
        }
        Serial.print(".");
        delay(250);
    }
    Serial.println(" timeout (TLS puede fallar)");
}

static bool initCamera()
{
    camera_config_t config = {};
    config.ledc_channel = LEDC_CHANNEL_0;
    config.ledc_timer = LEDC_TIMER_0;
    config.pin_d0 = Y2_GPIO_NUM;
    config.pin_d1 = Y3_GPIO_NUM;
    config.pin_d2 = Y4_GPIO_NUM;
    config.pin_d3 = Y5_GPIO_NUM;
    config.pin_d4 = Y6_GPIO_NUM;
    config.pin_d5 = Y7_GPIO_NUM;
    config.pin_d6 = Y8_GPIO_NUM;
    config.pin_d7 = Y9_GPIO_NUM;
    config.pin_xclk = XCLK_GPIO_NUM;
    config.pin_pclk = PCLK_GPIO_NUM;
    config.pin_vsync = VSYNC_GPIO_NUM;
    config.pin_href = HREF_GPIO_NUM;
    config.pin_sccb_sda = SIOD_GPIO_NUM;
    config.pin_sccb_scl = SIOC_GPIO_NUM;
    config.pin_pwdn = PWDN_GPIO_NUM;
    config.pin_reset = RESET_GPIO_NUM;
    config.xclk_freq_hz = XCLK_HZ;
    config.pixel_format = PIXFORMAT_RGB565;
    config.frame_size = FRAMESIZE_QVGA;
    config.jpeg_quality = 12;
    config.fb_count = 2;
    config.fb_location = CAMERA_FB_IN_PSRAM;
    config.grab_mode = CAMERA_GRAB_LATEST;

    const esp_err_t err = esp_camera_init(&config);
    if (err != ESP_OK) {
        Serial.printf("ERROR iniciando cámara: 0x%x\n", err);
        return false;
    }

    sensor_t *s = esp_camera_sensor_get();
    if (s != nullptr) {
        Serial.printf("Sensor PID: 0x%04X\n", s->id.PID);
    }
    Serial.println("Camara OK");
    return true;
}

static const char *wifiStatusText(wl_status_t status)
{
    switch (status) {
    case WL_IDLE_STATUS:
        return "IDLE";
    case WL_NO_SSID_AVAIL:
        return "NO_SSID";
    case WL_SCAN_COMPLETED:
        return "SCAN";
    case WL_CONNECTED:
        return "OK";
    case WL_CONNECT_FAILED:
        return "AUTH_FAIL";
    case WL_CONNECTION_LOST:
        return "LOST";
    case WL_DISCONNECTED:
        return "DISCONNECTED";
    default:
        return "?";
    }
}

static int apostropheLen(const char *text)
{
    const auto *bytes = reinterpret_cast<const uint8_t *>(text);
    if (bytes[0] == '\'') {
        return 1;
    }
    if (bytes[0] == 0xE2 && bytes[1] == 0x80 && (bytes[2] == 0x98 || bytes[2] == 0x99)) {
        return 3;
    }
    return 0;
}

static bool ssidLooseEqual(const char *seen, const char *wanted)
{
    while (true) {
        const int seenMark = apostropheLen(seen);
        const int wantedMark = apostropheLen(wanted);
        if (seenMark > 0 || wantedMark > 0) {
            if (seenMark == 0 || wantedMark == 0) {
                return false;
            }
            seen += seenMark;
            wanted += wantedMark;
            continue;
        }
        if (*seen != *wanted) {
            return false;
        }
        if (*seen == '\0') {
            return true;
        }
        ++seen;
        ++wanted;
    }
}

static char resolvedSsid[33];
static bool resolvedReady = false;

static const char *targetSsid()
{
    return resolvedReady ? resolvedSsid : WIFI_SSID;
}

static void adoptScannedSsid()
{
    const int count = WiFi.scanNetworks(false, true);
    if (count <= 0) {
        Serial.println("WiFi: ninguna red en 2.4 GHz");
        Serial.println("iPhone: Ajustes > Hotspot personal > Maximizar compatibilidad");
        WiFi.scanDelete();
        return;
    }

    bool found = false;
    for (int i = 0; i < count; i++) {
        const String ssid = WiFi.SSID(i);
        Serial.printf("  red: \"%s\" rssi=%d\n", ssid.c_str(), WiFi.RSSI(i));
        if (found || !ssidLooseEqual(ssid.c_str(), WIFI_SSID)) {
            continue;
        }
        strncpy(resolvedSsid, ssid.c_str(), sizeof(resolvedSsid) - 1);
        resolvedSsid[sizeof(resolvedSsid) - 1] = '\0';
        resolvedReady = true;
        found = true;
        if (strcmp(resolvedSsid, WIFI_SSID) != 0) {
            Serial.println("WiFi: el apostrofe del iPhone no es el del teclado; uso el nombre real");
        }
    }
    if (!found) {
        Serial.printf("WiFi: no esta en el aire \"%s\"\n", WIFI_SSID);
    }
    WiFi.scanDelete();
}

static void beginWifi()
{
    WiFi.mode(WIFI_STA);
    WiFi.setSleep(false);
    WiFi.begin(targetSsid(), WIFI_PASS);
}

static void startWifi()
{
    WiFi.persistent(false);
    WiFi.setAutoReconnect(true);
    Serial.printf("WiFi buscando \"%s\"\n", WIFI_SSID);
    beginWifi();
}

static void maintainWifi()
{
    static uint32_t lastAttemptMs = 0;
    static uint8_t failures = 0;
    if (WiFi.status() == WL_CONNECTED) {
        failures = 0;
        return;
    }

    const uint32_t now = millis();
    if (now - lastAttemptMs < 8000) {
        return;
    }
    lastAttemptMs = now;
    failures++;
    const wl_status_t status = WiFi.status();
    Serial.printf("WiFi reintento (%s)\n", wifiStatusText(status));
    if (status == WL_CONNECT_FAILED) {
        Serial.println("WiFi: la red existe pero rechazo la contrasena");
    }
    if (failures == 1 || failures % 3 == 0) {
        WiFi.disconnect(false, false);
        adoptScannedSsid();
    } else {
        WiFi.disconnect(false, false);
    }
    beginWifi();
}

static void connectBackend()
{
    char path[192];
    snprintf(path, sizeof(path), "/camera?token=%s", JARVIS_DEVICE_TOKEN);

    Serial.printf("Backend wss://%s:%d%s\n", JARVIS_BACKEND_HOST,
                  JARVIS_BACKEND_PORT, path);

    webSocket.onEvent(onWsEvent);
    webSocket.setReconnectInterval(5000);

#if JARVIS_USE_TLS

    webSocket.beginSSL(JARVIS_BACKEND_HOST, JARVIS_BACKEND_PORT, path);
#else
    webSocket.begin(JARVIS_BACKEND_HOST, JARVIS_BACKEND_PORT, path);
#endif

    if (audioReady) {
        voiceConnect(JARVIS_BACKEND_HOST, JARVIS_BACKEND_PORT, JARVIS_VOICE_TOKEN,
                     JARVIS_USE_TLS);
    }
}

static void pollButton()
{
    static bool stableLevel = HIGH;
    static bool lastReading = HIGH;
    static uint32_t lastChangeMs = 0;

    const bool reading = digitalRead(BUTTON_PIN);
    const uint32_t now = millis();
    if (reading != lastReading) {
        lastReading = reading;
        lastChangeMs = now;
        return;
    }
    if (reading == stableLevel || now - lastChangeMs < BUTTON_DEBOUNCE_MS) {
        return;
    }

    stableLevel = reading;
    if (stableLevel == LOW) {
        Serial.println("boton");
        robotEyesPlayHappy();
        if (audioReady) {
            voiceToggleSession();
        }
    }
}

static void uploadFrame()
{
    camera_fb_t *fb = esp_camera_fb_get();
    if (!fb) {
        return;
    }

    uint8_t *jpg_buf = nullptr;
    size_t jpg_len = 0;
    const bool ok = frame2jpg(fb, JPEG_QUALITY, &jpg_buf, &jpg_len);
    esp_camera_fb_return(fb);

    if (!ok || jpg_buf == nullptr || jpg_len == 0) {
        return;
    }

    webSocket.sendBIN(jpg_buf, jpg_len);
    free(jpg_buf);
}

void setup()
{
    Serial.begin(115200);

#if ARDUINO_USB_CDC_ON_BOOT
    Serial.setTxTimeoutMs(0);
#endif
    delay(200);
    Serial.println();
    Serial.println("ESP32-S3 CAMERA → jarvis.gms-app.com");

    if (strcmp(JARVIS_DEVICE_TOKEN, "jdv_replace_me") == 0) {
        Serial.println("FALTA TOKEN: crea un dispositivo en Config y pégalo en secrets.h");
    }

    if (psramFound()) {
        Serial.printf("PSRAM: %.2f MB\n", ESP.getPsramSize() / 1024.0 / 1024.0);
    } else {
        Serial.println("PSRAM NO encontrada");
    }

    esp_log_level_set("cam_hal", ESP_LOG_NONE);

    pinMode(BUTTON_PIN, INPUT_PULLUP);
    pinMode(LED_PIN, OUTPUT);
    digitalWrite(LED_PIN, LOW);
    robotEyesBegin(OLED_SDA_PIN, OLED_SCL_PIN);
    cameraReady = initCamera();
    audioReady = voiceBegin();
    startWifi();
}

void loop()
{
    if (!cameraReady) {
        static uint32_t lastCamMs = 0;
        const uint32_t now = millis();
        if (now - lastCamMs > 5000) {
            lastCamMs = now;
            esp_camera_deinit();
            cameraReady = initCamera();
        }
    }

    maintainWifi();

    if (WiFi.status() == WL_CONNECTED) {
        static bool wifiLogged = false;
        if (!wifiLogged) {
            wifiLogged = true;
            Serial.print("WiFi IP ");
            Serial.println(WiFi.localIP());
        }
        if (!ntpDone) {
            waitForNtp();
            ntpDone = true;
        }
        if (!backendStarted) {
            connectBackend();
            backendStarted = true;
        }
    }

    if (backendStarted) {
        webSocket.loop();
        voiceLoop();
    }

    pollButton();
    updateLed();

    if (!wsConnected) {
        robotEyesSetMood(EyesMood::Connecting);
    } else {
        robotEyesSetMood(streamEnabled || voiceInSession() ? EyesMood::Watching
                                                           : EyesMood::Idle);
    }

    static uint32_t lastFrameMs = 0;
    static uint32_t frames = 0;
    static uint32_t windowStart = 0;

    if (!wsConnected || !streamEnabled || !cameraReady) {
        delay(voiceInSession() ? 1 : 20);
        return;
    }

    const uint32_t now = millis();
    const uint32_t gap = voiceInSession() ? CALL_FRAME_GAP_MS : MIN_FRAME_GAP_MS;
    if (now - lastFrameMs < gap) {
        return;
    }
    lastFrameMs = now;

    if (windowStart == 0) {
        windowStart = now;
    }

    uploadFrame();
    frames++;
    if (frames >= 50) {
        const uint32_t elapsed = now - windowStart;
        if (elapsed > 0) {
            Serial.printf("uplink FPS: %.1f\n", frames * 1000.0f / elapsed);
        }
        frames = 0;
        windowStart = now;
    }
}
