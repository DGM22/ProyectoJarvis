#pragma once

#include <stdint.h>

enum class EyesMood : uint8_t {
    Connecting,
    Idle,
    Watching,
};

bool robotEyesBegin(int sdaPin, int sclPin);

void robotEyesSetMood(EyesMood mood);

void robotEyesPlayHappy();
